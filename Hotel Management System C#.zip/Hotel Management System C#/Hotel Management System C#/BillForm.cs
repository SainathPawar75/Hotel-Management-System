﻿using System;
using System.Windows.Forms;

namespace Hotel_Management_System_C_
{
    public partial class BillForm : Form
    {
        public BillForm(string billDetails)
        {

            InitializeComponent();
            txtBill.Text = billDetails;
        }

        private void lblHeading_Click(object sender, EventArgs e)
        {

        }

        private void txtBill_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
