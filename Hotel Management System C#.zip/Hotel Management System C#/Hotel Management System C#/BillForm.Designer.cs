﻿namespace Hotel_Management_System_C_
{
    partial class BillForm
    {
        private System.Windows.Forms.TextBox txtBill;
        private System.Windows.Forms.Label lblHeading;

        private void InitializeComponent()
        {
            txtBill = new System.Windows.Forms.TextBox();
            lblHeading = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // txtBill
            // 
            txtBill.BackColor = System.Drawing.Color.White;
            txtBill.Dock = System.Windows.Forms.DockStyle.Fill;
            txtBill.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtBill.Location = new System.Drawing.Point(0, 30);
            txtBill.Multiline = true;
            txtBill.Name = "txtBill";
            txtBill.ReadOnly = true;
            txtBill.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            txtBill.Size = new System.Drawing.Size(895, 414);
            txtBill.TabIndex = 1;
            txtBill.TextChanged += txtBill_TextChanged;
            // 
            // lblHeading
            // 
            lblHeading.Dock = System.Windows.Forms.DockStyle.Top;
            lblHeading.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblHeading.Location = new System.Drawing.Point(0, 0);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new System.Drawing.Size(895, 30);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "|| Shree Sai Hotel || ";
            lblHeading.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            lblHeading.Click += lblHeading_Click;
            // 
            // BillForm
            // 
            ClientSize = new System.Drawing.Size(895, 444);
            Controls.Add(txtBill);
            Controls.Add(lblHeading);
            Name = "BillForm";
            Text = "Hotel Management Project";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
