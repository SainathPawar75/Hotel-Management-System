﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Hotel_Management_System_C_
{
    public partial class Dashboard : Form
    {
        SqlConnection cn = new SqlConnection(@"Data Source=LAPTOP-52UK67GC\SQLEXPRESS;Initial Catalog=ResturantManagementSystem;Persist Security Info=True;User Id=sai;Password=sai1234");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        private string connectionString = @"Data Source=LAPTOP-52UK67GC\SQLEXPRESS; Database = ResturantManagementSystem;User Id=sai;Password=sai1234;";

        public Dashboard()
        {
            InitializeComponent();
            
        }

        private void Dashboard_Load_1(object sender, EventArgs e)
        {
            SetCombobox();
            AddSubmitButtonColumn();
        }


        public Dashboard(string userName, string Gmail)
        {
            InitializeComponent();
            lblGreeting.Text = $"{userName}"; // Assuming lblGreeting is a label on your Dashboard form
            lblGmail.Text = $"EmailID: {Gmail}"; // Assuming lblGmail is a label to display the email address
        }
    

        private void SetCombobox()
        {
            try
            {
                if (cn.State != ConnectionState.Open)
                    cn.Open();

                cmd = new SqlCommand("GetTableDetails", cn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                GridTables.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
        }


        private void btn_save_Click(object sender, EventArgs e)
        {

            try
            {
                DataTable dataTable = (DataTable)GridTables.DataSource;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    foreach (DataRow row in dataTable.Rows)
                    {
                        if (row.RowState == DataRowState.Modified)
                        {
                            using (SqlCommand cmd = new SqlCommand("UPDATE TABLES SET Alloted = @Alloted WHERE TableId = @TableId", conn))
                            {
                                cmd.Parameters.AddWithValue("@Alloted", row["Alloted"]);
                                cmd.Parameters.AddWithValue("@TableId", row["TableId"]);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            MessageBox.Show("Table Updated");
        }

        private void AddSubmitButtonColumn()
        {
            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            buttonColumn.Name = "SubmitButton";
            buttonColumn.HeaderText = "Submit";
            buttonColumn.Text = "Submit";
            buttonColumn.UseColumnTextForButtonValue = true;
            GridTables.Columns.Add(buttonColumn);

            GridTables.CellClick += new DataGridViewCellEventHandler(GridTables_CellClick);
        }

        private void GridTables_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == GridTables.Columns["SubmitButton"].Index && e.RowIndex >= 0)
            {
                // Get the TableId and Alloted values of the clicked row
                int tableId = Convert.ToInt32(GridTables.Rows[e.RowIndex].Cells["TableId"].Value);
                bool alloted = Convert.ToBoolean(GridTables.Rows[e.RowIndex].Cells["Alloted"].Value);


                if (alloted)
                {
                    MessageBox.Show("Table is alreadt been alloted !!");
                }
                else
                {
                    // Implement your functionality here
                    MessageBox.Show($"TableId: {tableId}, Alloted: {alloted}");

                    // Optionally, you can update the Alloted status in the database
                    UpdateAllotedStatus(tableId, alloted);

                    //Open New GetOrder Form after this 

                    this.Hide();
                    GetOrder getOrder = new GetOrder(tableId);
                    getOrder.ShowDialog();
                }

            }
        }

        private void UpdateAllotedStatus(int tableId, bool alloted)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("UPDATE TABLES SET Alloted = @Alloted WHERE TableId = @TableId", conn))
                    {
                        cmd.Parameters.AddWithValue("@Alloted", !alloted); // Toggle the Alloted status
                        cmd.Parameters.AddWithValue("@TableId", tableId);
                        cmd.ExecuteNonQuery();
                    }
                }
                SetCombobox();
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"General Error: {ex.Message}");
            }
        }
        private void LogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Show the login form and close the current form
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Close();

        }

        private void Name_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Current User: {lblGreeting.Text}");
        }

        private void Gmail_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Current User: {lblGmail.Text}");

        }
    }
}

