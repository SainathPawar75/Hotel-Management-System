﻿using Hotel_Management_System_C_;
using System.Windows.Forms;
using System;

namespace Hotel_Management_System_C_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            guna2AnimateWindow2 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            txtUsername = new Guna.UI2.WinForms.Guna2TextBox();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            panel1 = new Panel();
            BtnExit_Click = new PictureBox();
            label3 = new Label();
            labelError = new Label();
            label1 = new Label();
            button1 = new Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2BorderlessForm2 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2ImageRadioButton1 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton5 = new Guna.UI2.WinForms.Guna2CircleButton();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BtnExit_Click).BeginInit();
            SuspendLayout();
            // 
            // guna2CirclePictureBox2
            // 
            guna2CirclePictureBox2.Image = Properties.Resources.login;
            guna2CirclePictureBox2.ImageRotate = 0F;
            guna2CirclePictureBox2.Location = new System.Drawing.Point(11, 61);
            guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            guna2CirclePictureBox2.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox2.Size = new System.Drawing.Size(328, 295);
            guna2CirclePictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2CirclePictureBox2.TabIndex = 0;
            guna2CirclePictureBox2.TabStop = false;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            guna2CirclePictureBox1.Image = Properties.Resources.circular_loading;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new System.Drawing.Point(11, 32);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new System.Drawing.Size(336, 336);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2CirclePictureBox1.TabIndex = 1;
            guna2CirclePictureBox1.TabStop = false;
            guna2CirclePictureBox1.UseTransparentBackground = true;
            // 
            // txtUsername
            // 
            txtUsername.BorderRadius = 18;
            txtUsername.CustomizableEdges = customizableEdges11;
            txtUsername.DefaultText = "";
            txtUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
            txtUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
            txtUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
            txtUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
            txtUsername.FillColor = System.Drawing.Color.Silver;
            txtUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
            txtUsername.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            txtUsername.ForeColor = System.Drawing.Color.Gray;
            txtUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
            txtUsername.IconLeft = Properties.Resources.user_25px1;
            txtUsername.IconLeftSize = new System.Drawing.Size(30, 30);
            txtUsername.Location = new System.Drawing.Point(411, 115);
            txtUsername.Margin = new Padding(4, 5, 4, 5);
            txtUsername.Name = "txtUsername";
            txtUsername.PasswordChar = '\0';
            txtUsername.PlaceholderForeColor = System.Drawing.Color.Gray;
            txtUsername.PlaceholderText = "Username";
            txtUsername.SelectedText = "";
            txtUsername.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtUsername.Size = new System.Drawing.Size(313, 57);
            txtUsername.TabIndex = 2;
            txtUsername.TextAlign = HorizontalAlignment.Center;
            txtUsername.TextChanged += txtUsername_TextChanged;
            // 
            // txtPassword
            // 
            txtPassword.BorderRadius = 18;
            txtPassword.CustomizableEdges = customizableEdges13;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
            txtPassword.FillColor = System.Drawing.Color.Silver;
            txtPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
            txtPassword.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            txtPassword.ForeColor = System.Drawing.Color.Gray;
            txtPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
            txtPassword.IconLeft = (System.Drawing.Image)resources.GetObject("txtPassword.IconLeft");
            txtPassword.IconLeftSize = new System.Drawing.Size(30, 30);
            txtPassword.Location = new System.Drawing.Point(411, 191);
            txtPassword.Margin = new Padding(4, 5, 4, 5);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderForeColor = System.Drawing.Color.Gray;
            txtPassword.PlaceholderText = "Password";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtPassword.Size = new System.Drawing.Size(313, 57);
            txtPassword.TabIndex = 3;
            txtPassword.TextAlign = HorizontalAlignment.Center;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.BackColor = System.Drawing.Color.White;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(BtnExit_Click);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(labelError);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(txtUsername);
            panel1.Controls.Add(guna2CirclePictureBox1);
            panel1.Controls.Add(guna2CirclePictureBox2);
            panel1.Location = new System.Drawing.Point(310, 124);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(829, 436);
            panel1.TabIndex = 0;
            // 
            // BtnExit_Click
            // 
            BtnExit_Click.Image = Properties.Resources.cancel_50px;
            BtnExit_Click.Location = new System.Drawing.Point(3, 3);
            BtnExit_Click.Name = "BtnExit_Click";
            BtnExit_Click.Size = new System.Drawing.Size(54, 52);
            BtnExit_Click.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnExit_Click.TabIndex = 8;
            BtnExit_Click.TabStop = false;
            BtnExit_Click.Click += BtnExit_Click_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.Gray;
            label3.Location = new System.Drawing.Point(176, 409);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(565, 20);
            label3.TabIndex = 7;
            label3.Text = "*You are accept our terms and condition when you Login using valid credentials";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelError
            // 
            labelError.AutoSize = true;
            labelError.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            labelError.ForeColor = System.Drawing.Color.Tomato;
            labelError.Location = new System.Drawing.Point(449, 346);
            labelError.Name = "labelError";
            labelError.Size = new System.Drawing.Size(256, 22);
            labelError.TabIndex = 6;
            labelError.Text = "Wrong username Or Password";
            labelError.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.White;
            label1.Font = new System.Drawing.Font("Comic Sans MS", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(429, 32);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(267, 60);
            label1.TabIndex = 5;
            label1.Text = "User Login ";
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.LimeGreen;
            button1.Font = new System.Drawing.Font("Cambria", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.White;
            button1.Location = new System.Drawing.Point(449, 277);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(246, 57);
            button1.TabIndex = 4;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2BorderlessForm2
            // 
            guna2BorderlessForm2.ContainerControl = this;
            guna2BorderlessForm2.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm2.TransparentWhileDrag = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.login_image;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new System.Drawing.Size(1411, 605);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            SizeGripStyle = SizeGripStyle.Show;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Form1";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)BtnExit_Click).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2CirclePictureBox PictureBox2;
        private PictureBox BtnExit_Click;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtUsername;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm2;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton1;
        private Button button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Label label1;
        private Label labelError;
        private Label label3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton5;
        // private Guna.UI2.WinForms.Guna2CirclePictureBox PictureBox2;
    }
}

