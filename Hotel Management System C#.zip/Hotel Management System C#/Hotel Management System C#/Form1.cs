﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Hotel_Management_System_C_
{
    public partial class Form1 : Form
    {

        SqlConnection cn = new SqlConnection(@"Data Source=LAPTOP-52UK67GC\SQLEXPRESS;Initial Catalog=ResturantManagementSystem;Persist Security Info=True;User Id=sai;Password=sai1234");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;

        public Form1()
        {
            InitializeComponent();
        }


        private void BtnExit_Click_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (cn.State != ConnectionState.Open)
                cn.Open();

            cmd = new SqlCommand("GetUser", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmailId", txtUsername.Text.ToString());
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text.ToString());
            cmd.CommandType = CommandType.StoredProcedure;
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                string Gmail = dt.Rows[0]["EmailId"].ToString();
                string userName = dt.Rows[0]["UserName"].ToString();

                this.Hide();
                Dashboard dashboard = new Dashboard(userName,Gmail);
              
                dashboard.ShowDialog();
                this.Show(); // Show the login form again after Dashboard is closed
            }
            else
            {
                labelError.Visible = true;
                await Task.Delay(3000);
                labelError.Visible = false;
                txtPassword.Clear();

            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
