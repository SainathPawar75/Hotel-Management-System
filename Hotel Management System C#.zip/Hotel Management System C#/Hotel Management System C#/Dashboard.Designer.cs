﻿namespace Hotel_Management_System_C_
{
    partial class Dashboard
    {
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        private void InitializeComponent()
        {
            label1 = new System.Windows.Forms.Label();
            cb_GetTables = new System.Windows.Forms.ComboBox();
            GridTables = new System.Windows.Forms.DataGridView();
            panel1 = new System.Windows.Forms.Panel();
            panel4 = new System.Windows.Forms.Panel();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            panel2 = new System.Windows.Forms.Panel();
            panel3 = new System.Windows.Forms.Panel();
            LogOut = new System.Windows.Forms.LinkLabel();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            panel5 = new System.Windows.Forms.Panel();
            lblGmail = new System.Windows.Forms.Label();
            lblGreeting = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)GridTables).BeginInit();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(317, 180);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(215, 27);
            label1.TabIndex = 1;
            label1.Text = "Get Free Tables :- ";
            // 
            // cb_GetTables
            // 
            cb_GetTables.FormattingEnabled = true;
            cb_GetTables.Location = new System.Drawing.Point(575, 172);
            cb_GetTables.Name = "cb_GetTables";
            cb_GetTables.Size = new System.Drawing.Size(182, 33);
            cb_GetTables.TabIndex = 2;
            // 
            // GridTables
            // 
            GridTables.AccessibleRole = System.Windows.Forms.AccessibleRole.Clock;
            GridTables.AllowUserToOrderColumns = true;
            GridTables.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            GridTables.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            GridTables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            GridTables.Location = new System.Drawing.Point(310, 224);
            GridTables.Name = "GridTables";
            GridTables.RightToLeft = System.Windows.Forms.RightToLeft.No;
            GridTables.RowHeadersWidth = 62;
            GridTables.RowTemplate.Height = 33;
            GridTables.ShowEditingIcon = false;
            GridTables.Size = new System.Drawing.Size(725, 329);
            GridTables.TabIndex = 5;
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.FromArgb(37, 198, 218);
            panel1.Controls.Add(panel4);
            panel1.Dock = System.Windows.Forms.DockStyle.Left;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(304, 664);
            panel1.TabIndex = 6;
            // 
            // panel4
            // 
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(pictureBox1);
            panel4.Location = new System.Drawing.Point(4, 3);
            panel4.Name = "panel4";
            panel4.Size = new System.Drawing.Size(300, 233);
            panel4.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(96, 168);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(95, 27);
            label3.TabIndex = 2;
            label3.Text = "System";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(37, 132);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(223, 27);
            label2.TabIndex = 1;
            label2.Text = "Hotel Management";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_home_page_100;
            pictureBox1.Location = new System.Drawing.Point(80, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(127, 126);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = System.Drawing.Color.FromArgb(37, 198, 218);
            panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            panel2.Location = new System.Drawing.Point(304, 559);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(1040, 105);
            panel2.TabIndex = 7;
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.Color.White;
            panel3.Controls.Add(LogOut);
            panel3.Controls.Add(pictureBox2);
            panel3.Dock = System.Windows.Forms.DockStyle.Top;
            panel3.Location = new System.Drawing.Point(304, 0);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(1040, 83);
            panel3.TabIndex = 8;
            // 
            // LogOut
            // 
            LogOut.ActiveLinkColor = System.Drawing.Color.FromArgb(37, 198, 21);
            LogOut.AutoSize = true;
            LogOut.BackColor = System.Drawing.Color.WhiteSmoke;
            LogOut.Font = new System.Drawing.Font("HP Simplified Hans", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            LogOut.Location = new System.Drawing.Point(938, 55);
            LogOut.Name = "LogOut";
            LogOut.Size = new System.Drawing.Size(65, 18);
            LogOut.TabIndex = 0;
            LogOut.TabStop = true;
            LogOut.Text = "LogOut";
            LogOut.LinkClicked += LogOut_LinkClicked;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icons8_account_100;
            pictureBox2.Location = new System.Drawing.Point(863, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(73, 79);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = System.Drawing.Color.FromArgb(37, 198, 218);
            panel5.Controls.Add(lblGmail);
            panel5.Controls.Add(lblGreeting);
            panel5.Controls.Add(label5);
            panel5.Location = new System.Drawing.Point(304, 76);
            panel5.Name = "panel5";
            panel5.Size = new System.Drawing.Size(1040, 74);
            panel5.TabIndex = 9;
            // 
            // lblGmail
            // 
            lblGmail.AutoSize = true;
            lblGmail.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            lblGmail.Location = new System.Drawing.Point(403, 26);
            lblGmail.Name = "lblGmail";
            lblGmail.Size = new System.Drawing.Size(106, 27);
            lblGmail.TabIndex = 5;
            lblGmail.Text = "lblGmail";
            lblGmail.Click += Gmail_Click;
            // 
            // lblGreeting
            // 
            lblGreeting.AutoSize = true;
            lblGreeting.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            lblGreeting.Location = new System.Drawing.Point(257, 26);
            lblGreeting.Name = "lblGreeting";
            lblGreeting.Size = new System.Drawing.Size(138, 27);
            lblGreeting.TabIndex = 4;
            lblGreeting.Text = "lblGreeting";
            lblGreeting.Click += Name_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(42, 26);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(209, 27);
            label5.TabIndex = 3;
            label5.Text = "Welcome Mrs/Ms.";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.White;
            BackgroundImage = Properties.Resources.lobby_v1713504_19_1440_1024x6831;
            ClientSize = new System.Drawing.Size(1344, 664);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(GridTables);
            Controls.Add(cb_GetTables);
            Controls.Add(label1);
            ImeMode = System.Windows.Forms.ImeMode.Off;
            Name = "Dashboard";
            ShowIcon = false;
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Hotel Management Project";
            TopMost = true;
            Load += Dashboard_Load_1;
            ((System.ComponentModel.ISupportInitialize)GridTables).EndInit();
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_GetTables;
        private System.Windows.Forms.DataGridView GridTables;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel LogOut;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblGreeting;
        private System.Windows.Forms.Label lblGmail;
    }
}