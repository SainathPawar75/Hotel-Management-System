﻿namespace Hotel_Management_System_C_
{
    partial class GetOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GetOrder));
            rbtn_veg = new System.Windows.Forms.RadioButton();
            rbtn_nonveg = new System.Windows.Forms.RadioButton();
            gridFoodOrder = new System.Windows.Forms.DataGridView();
            gridViewOrderDetails = new System.Windows.Forms.DataGridView();
            label1 = new System.Windows.Forms.Label();
            lbl_tableNo = new System.Windows.Forms.Label();
            Report = new System.Windows.Forms.Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            ((System.ComponentModel.ISupportInitialize)gridFoodOrder).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridViewOrderDetails).BeginInit();
            SuspendLayout();
            // 
            // rbtn_veg
            // 
            rbtn_veg.AutoSize = true;
            rbtn_veg.BackColor = System.Drawing.Color.LemonChiffon;
            rbtn_veg.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            rbtn_veg.Location = new System.Drawing.Point(840, 38);
            rbtn_veg.Name = "rbtn_veg";
            rbtn_veg.Size = new System.Drawing.Size(79, 31);
            rbtn_veg.TabIndex = 0;
            rbtn_veg.TabStop = true;
            rbtn_veg.Text = "Veg";
            rbtn_veg.UseVisualStyleBackColor = false;
            rbtn_veg.CheckedChanged += rbtn_veg_CheckedChanged_1;
            // 
            // rbtn_nonveg
            // 
            rbtn_nonveg.AutoSize = true;
            rbtn_nonveg.BackColor = System.Drawing.Color.MistyRose;
            rbtn_nonveg.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            rbtn_nonveg.Location = new System.Drawing.Point(945, 38);
            rbtn_nonveg.Name = "rbtn_nonveg";
            rbtn_nonveg.Size = new System.Drawing.Size(134, 31);
            rbtn_nonveg.TabIndex = 1;
            rbtn_nonveg.TabStop = true;
            rbtn_nonveg.Text = "Non-Veg";
            rbtn_nonveg.UseVisualStyleBackColor = false;
            rbtn_nonveg.CheckedChanged += rbtn_nonveg_CheckedChanged;
            // 
            // gridFoodOrder
            // 
            gridFoodOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridFoodOrder.Location = new System.Drawing.Point(78, 91);
            gridFoodOrder.Name = "gridFoodOrder";
            gridFoodOrder.RowHeadersWidth = 62;
            gridFoodOrder.RowTemplate.Height = 33;
            gridFoodOrder.Size = new System.Drawing.Size(1046, 68);
            gridFoodOrder.TabIndex = 2;
            gridFoodOrder.Visible = false;
            // 
            // gridViewOrderDetails
            // 
            gridViewOrderDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridViewOrderDetails.Location = new System.Drawing.Point(78, 108);
            gridViewOrderDetails.Name = "gridViewOrderDetails";
            gridViewOrderDetails.RowHeadersWidth = 62;
            gridViewOrderDetails.RowTemplate.Height = 33;
            gridViewOrderDetails.Size = new System.Drawing.Size(1046, 439);
            gridViewOrderDetails.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(231, 38);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(304, 27);
            label1.TabIndex = 4;
            label1.Text = "Order For Table Number :-";
            label1.Click += label1_Click;
            // 
            // lbl_tableNo
            // 
            lbl_tableNo.AutoSize = true;
            lbl_tableNo.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            lbl_tableNo.Location = new System.Drawing.Point(562, 38);
            lbl_tableNo.Name = "lbl_tableNo";
            lbl_tableNo.Size = new System.Drawing.Size(26, 27);
            lbl_tableNo.TabIndex = 5;
            lbl_tableNo.Text = "0";
            // 
            // Report
            // 
            Report.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            Report.BackColor = System.Drawing.Color.FromArgb(0, 192, 0);
            Report.Font = new System.Drawing.Font("HP Simplified Hans", 11.999999F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            Report.Image = (System.Drawing.Image)resources.GetObject("Report.Image");
            Report.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Report.Location = new System.Drawing.Point(521, 553);
            Report.Name = "Report";
            Report.Size = new System.Drawing.Size(210, 50);
            Report.TabIndex = 6;
            Report.Text = "   Print Bill";
            Report.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            Report.UseCompatibleTextRendering = true;
            Report.UseMnemonic = false;
            Report.UseVisualStyleBackColor = false;
            Report.Click += Report_Click;
            // 
            // GetOrder
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.login_image;
            BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            ClientSize = new System.Drawing.Size(1278, 659);
            Controls.Add(Report);
            Controls.Add(lbl_tableNo);
            Controls.Add(label1);
            Controls.Add(gridViewOrderDetails);
            Controls.Add(gridFoodOrder);
            Controls.Add(rbtn_nonveg);
            Controls.Add(rbtn_veg);
            Name = "GetOrder";
            Text = "Hotel Management Project";
            ((System.ComponentModel.ISupportInitialize)gridFoodOrder).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridViewOrderDetails).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.RadioButton rbtn_veg;
        private System.Windows.Forms.RadioButton rbtn_nonveg;
        private System.Windows.Forms.DataGridView gridFoodOrder;
        private System.Windows.Forms.DataGridView gridViewOrderDetails;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lbl_tableNo;
        private System.Windows.Forms.Button Report;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        //  private System.Windows.Forms.Button btnGenerateBill_Click;
    }
}