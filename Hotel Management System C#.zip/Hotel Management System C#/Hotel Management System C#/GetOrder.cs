﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace Hotel_Management_System_C_
{
    public partial class GetOrder : Form
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        private string connectionString = @"Data Source=LAPTOP-52UK67GC\SQLEXPRESS; Database = ResturantManagementSystem;User Id=sai;Password=sai1234;";

        public int _tableNo { get; set; }
        DataTable _dt = new DataTable();
        private Button button1_Click;
        private System.Windows.Forms.Button btnGenerateReport;



        public GetOrder(int tableNO)
        {
            _tableNo = tableNO;
            InitializeComponent();
            DataColumn comboBoxColumn = new DataColumn("Item_Name", typeof(string));
            DataColumn textColumn = new DataColumn("Rate", typeof(string));
            _dt.Columns.Add(comboBoxColumn);
            _dt.Columns.Add(textColumn);
            InitializeDataGridView();
            lbl_tableNo.Text = _tableNo.ToString();
        }

        private void InitializeDataGridView()
        {
            gridViewOrderDetails.AllowUserToAddRows = true;
            gridViewOrderDetails.AllowUserToDeleteRows = false;
            gridViewOrderDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridViewOrderDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            gridViewOrderDetails.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "Item_Name",
                Name = "comboBoxColumn",
                DataPropertyName = "Item_Name",
                Width = 200,
                DataSource = _dt,
                DisplayMember = "Item_Name",
                ValueMember = "Item_Name"
            });

            gridViewOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Rate",
                Name = "rateColumn",
                DataPropertyName = "Rate",
                ReadOnly = true // Rate is fixed and read-only
            });

            gridViewOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Quantity",
                Name = "quantityColumn",
                DataPropertyName = "Quantity"
            });

            gridViewOrderDetails.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Total",
                Name = "totalColumn",
                DataPropertyName = "Total",
                ReadOnly = true
            });

            gridViewOrderDetails.EditingControlShowing += GridViewOrderDetails_EditingControlShowing;
            gridViewOrderDetails.DataError += GridViewOrderDetails_DataError;
            gridViewOrderDetails.CellValueChanged += GridViewOrderDetails_CellValueChanged;
            gridViewOrderDetails.CellEndEdit += GridViewOrderDetails_CellEndEdit;
        }

        private void GridViewOrderDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (gridViewOrderDetails.CurrentCell.ColumnIndex == gridViewOrderDetails.Columns["comboBoxColumn"].Index && e.Control is ComboBox comboBox)
            {
                comboBox.SelectedIndexChanged -= ComboBox_SelectedIndexChanged;
                comboBox.SelectedIndexChanged += ComboBox_SelectedIndexChanged;
            }
        }

        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is DataRowView selectedRow)
            {
                gridViewOrderDetails.CurrentRow.Cells["rateColumn"].Value = selectedRow["Rate"].ToString();
            }
        }

        private void GridViewOrderDetails_DataError(object sender, DataGridViewDataErrorEventArgs e) { /* Handle errors */ }

        private void GridViewOrderDetails_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && (e.ColumnIndex == gridViewOrderDetails.Columns["quantityColumn"].Index || e.ColumnIndex == gridViewOrderDetails.Columns["rateColumn"].Index))
            {
                CalculateTotalForRow(e.RowIndex);
            }
        }

        private void GridViewOrderDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == gridViewOrderDetails.Columns["quantityColumn"].Index)
            {
                CalculateTotalForRow(e.RowIndex);
            }
        }

        private void CalculateTotalForRow(int rowIndex)
        {
            var row = gridViewOrderDetails.Rows[rowIndex];
            if (decimal.TryParse(row.Cells["quantityColumn"].Value?.ToString(), out var quantity) && decimal.TryParse(row.Cells["rateColumn"].Value?.ToString(), out var rate))
            {
                row.Cells["totalColumn"].Value = quantity * rate;
            }
            else
            {
                row.Cells["totalColumn"].Value = null;
            }
        }

        private void rbtn_veg_CheckedChanged_1(object sender, EventArgs e)
        {
            LoadMenuItems("GetMenuItems 2");
        }

        private void rbtn_nonveg_CheckedChanged(object sender, EventArgs e)
        {
            LoadMenuItems("GetMenuItems 1");
        }


        private void LoadMenuItems(string query)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        da = new SqlDataAdapter(cmd);
                        _dt.Clear();
                        da.Fill(_dt);
                        gridFoodOrder.DataSource = _dt;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"General Error: {ex.Message}");
            }


        }

        private void Report_Click(object sender, EventArgs e)
        {
            StringBuilder billDetails = new StringBuilder();
            decimal grandTotal = 0;

            // Heading
            billDetails.AppendLine("Table No: " + _tableNo);
            billDetails.AppendLine("=================================================================");
            billDetails.AppendLine($"{"Item",-20} {"Rate",4}   {"Quantity",8}{"Total",10}");
            billDetails.AppendLine("=================================================================");

            // Bill Items
            foreach (DataGridViewRow row in gridViewOrderDetails.Rows)
            {
                if (row.Cells["comboBoxColumn"].Value != null &&
                    row.Cells["rateColumn"].Value != null &&
                    row.Cells["quantityColumn"].Value != null &&
                    row.Cells["totalColumn"].Value != null)
                {
                    string itemName = row.Cells["comboBoxColumn"].Value.ToString();
                    decimal rate = Convert.ToDecimal(row.Cells["rateColumn"].Value);
                    decimal quantity = Convert.ToDecimal(row.Cells["quantityColumn"].Value);
                    decimal total = Convert.ToDecimal(row.Cells["totalColumn"].Value);

                    // Format each line with fixed column widths
                    billDetails.AppendLine($"{itemName,-20} {rate,4} {quantity,8} {total,10}");
                    grandTotal += total;
                }
            }

            // Footer
            billDetails.AppendLine("=================================================================");
            billDetails.AppendLine($"{"Grand Total:",-33}  {grandTotal,10}");
            billDetails.AppendLine("=================================================================");
            billDetails.AppendLine("                      THANK YOU                                   ");


            // Hide the current form
            this.Hide();
            // Display the bill
            BillForm billForm = new BillForm(billDetails.ToString());
            billForm.ShowDialog();
            // Optionally, close the current form after the BillForm is closed
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}

